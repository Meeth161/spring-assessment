package com.meet.dao;

import com.meet.entity.Customer;

public interface CustomerDAO {
	
	public Customer getCustomer(String id);
	
}
