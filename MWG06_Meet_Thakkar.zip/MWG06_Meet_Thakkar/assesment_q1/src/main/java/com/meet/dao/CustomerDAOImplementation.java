package com.meet.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.meet.entity.Customer;
import com.meet.exceptions.CustomerNotFoundException;

@Repository
public class CustomerDAOImplementation implements CustomerDAO {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public Customer getCustomer(String id) {
		
		Session currentSession = sessionFactory.getCurrentSession();
		
		Customer customer = currentSession.get(Customer.class, getIntegerId(id));
		
		if (customer == null) {
			throw new CustomerNotFoundException("Customer id not found - " + id);
		}
		
		return customer;
	}

	private int getIntegerId(String id) {
		int intId;
		try {
			intId = Integer.parseInt(id);
		} catch (NumberFormatException e) {
			throw new CustomerNotFoundException("Customer Id Invalid");
		}

		return intId;
	}

}
