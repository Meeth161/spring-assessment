package com.meet.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "customer")
public class Customer {

	@Id
	@Column(name = "customer_id")
	private int customerId;
	
	@Column(name = "customer_name")
	private String customerName;
	
	@Column(name = "favourite_dish")
	private String favouriteDish;
	
	public Customer() {
		
	}

	public Customer(int customerId, String customerName, String favouriteDish) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.favouriteDish = favouriteDish;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getFavouriteDish() {
		return favouriteDish;
	}

	public void setFavouriteDish(String favouriteDish) {
		this.favouriteDish = favouriteDish;
	}
	
}
