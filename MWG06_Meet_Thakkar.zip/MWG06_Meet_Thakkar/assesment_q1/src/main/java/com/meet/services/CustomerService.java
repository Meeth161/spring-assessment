package com.meet.services;

import com.meet.entity.Customer;

public interface CustomerService {

	public Customer getCustomer(String id);
	
}
