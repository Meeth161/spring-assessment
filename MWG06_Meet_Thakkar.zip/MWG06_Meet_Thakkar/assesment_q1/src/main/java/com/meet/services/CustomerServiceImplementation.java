package com.meet.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.meet.dao.CustomerDAO;
import com.meet.entity.Customer;

@Service
public class CustomerServiceImplementation implements CustomerService {

	@Autowired
	private CustomerDAO customerDAO;
	
	@Override
	@Transactional
	public Customer getCustomer(String id) {
		return customerDAO.getCustomer(id);
	}

}
